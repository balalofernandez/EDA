package material.dictionary;

/**
 *
 * @author jvelez
 */
public class SCHashDictionary  <K,V> {
    
}
