package material.graphs;

import material.Position;

/**
 *
 * @author jvelez
 */
public interface Vertex <V> extends Position <V>
{
    
}
