package material.tree.binarytree;

import java.util.Iterator;
import material.Position;

/**
 *
 * @author mayte
 * @param <T>
 */
public class InternalNodeIterator<T> implements Iterator<Position<T>> {

    public InternalNodeIterator (BinaryTree<T> tree){
        
    }
    
    
    @Override
    public boolean hasNext() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Position<T> next() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
    }
    
}
