package material.tree.binarytree;

import material.Position;
import sun.awt.image.ImageWatched;

import java.util.LinkedList;

/**
 *
 * @author mayte
 * @param <T>
 */
public class MoreFunctionality<T> {

    /**
     * Check if a BinaryTree is perfect. 
     * A BinaryTree is perfect if all its internal nodes have left chlid and right child.
     * @param t
     * @return 
     */
    public boolean isPerfect(BinaryTree<T> t){
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }
    
    /**
     * Check if a BinaryTree is imperfect. 
     * A BinaryTree is imperfect if not all its internal nodes have left chlid and right child.
     * @param t
     * @return 
     */
    public boolean isImperfect(BinaryTree<T> t){
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }
    
    /**
     * Check if a BinaryTree is odd. 
     * A BinaryTree is odd if more than half its nodes are left child.
     * @param t
     * @return 
     */
    public boolean isOdd(BinaryTree<T> t){
        Position<T> root = t.root();
        LinkedList<Position<T>> hijosI = new LinkedList<>();
        LinkedList<Position<T>> hijosD = new LinkedList<>();
        Position<T> hi = null;
        Position<T> hd = null;
        int conti = 0;
        int contd = 0;
        if(t.hasLeft(root)){
            hi = t.left(root);
            hijosI.add(hi);
        }
        if(t.hasRight(root)) {
            hd = t.right(root);
            hijosI.add(hd);
        }
        if(hi != null && hd != null){//Vamos a hacer 2 for: uno hizq y otro hder
            for(Position<T> childs:t.children(hi)){
                hijosI.addFirst(childs);
                conti++;
            }
            for(Position<T> childs:t.children(hd)){
                hijosD.addFirst(childs);
            }
        }
        return conti>contd;

    }

    
    /**
     * Check if a BinaryTree is even. 
     * A BinaryTree is even if more than half its nodes are right child.
     * @param t
     * @return 
     */
    public boolean isEven(BinaryTree<T> t){
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }
    
    /**
     * Check if a BinaryTree is ambidextrous. 
     * A BinaryTree is ambidextrous if its left and right children doesn't differ in more than one.
     * @param t
     * @return 
     */
    public boolean isAmbidextrous(BinaryTree<T> t){
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }

}
