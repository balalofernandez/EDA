package practica4.parchis;

/**
 *
 * @author jvelez
 */
class ParchisChip {
    
}
